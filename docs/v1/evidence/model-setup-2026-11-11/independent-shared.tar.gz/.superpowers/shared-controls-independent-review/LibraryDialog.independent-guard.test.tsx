import {fireEvent,render,screen,waitFor} from '@testing-library/react';
import {it,expect,vi} from 'vitest';
import {LibraryDialog} from './LibraryDialog';
vi.mock('../../i18n',()=>({useI18n:()=>({t:{common:{close:'Close'}}})}));
it('does not refocus a still-connected opener when only the dialog unmounts',async()=>{
 function Example({show=false}:{show?:boolean}){return <><button>Persistent opener</button>{show&&<LibraryDialog open onOpenChange={()=>{}} title="Navigation dialog"><button>Inside</button></LibraryDialog>}<button>New route target</button></>;}
 const h=render(<Example/>);const opener=screen.getByRole('button',{name:'Persistent opener'});
 opener.focus();h.rerender(<Example show/>);const dialog=await screen.findByRole('dialog');
 await waitFor(()=>expect(dialog.contains(document.activeElement)).toBe(true));
 const focus=vi.spyOn(opener,'focus');focus.mockClear();h.rerender(<Example/>);
 const next=screen.getByRole('button',{name:'New route target'});next.focus();
 await new Promise(resolve=>setTimeout(resolve,30));expect(opener.isConnected).toBe(true);
 expect(focus).not.toHaveBeenCalled();expect(next).toHaveFocus();
});

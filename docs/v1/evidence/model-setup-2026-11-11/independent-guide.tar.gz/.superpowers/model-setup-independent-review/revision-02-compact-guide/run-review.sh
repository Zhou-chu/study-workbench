#!/usr/bin/env bash
# Serial synthetic-only rerun; uses existing prepared dependencies.
set -euo pipefail
repo="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
evidence="$repo/.superpowers/model-setup-independent-review/revision-02-compact-guide"
nodebin="${REVIEW_NODE_BIN:-/home/USER/study-workbench-deploy-20261107/tools/node-v24.19.0-linux-x64/bin}"
cd "$repo"
sha256sum -c "$evidence/reviewed-source.sha256"
cd "$repo/apps/web"
env -i PATH="$nodebin:/usr/bin:/bin" HOME="$evidence" CI=1 "$nodebin/node" ../../node_modules/vitest/vitest.mjs run src/features/settings/model-setup-journey.test.tsx src/features/settings/settings-controls.test.tsx src/features/settings/configuration.test.tsx src/features/settings/model-owner.test.ts src/features/settings/configuration-contracts.test.ts --maxWorkers=2 2>&1 | tee "$evidence/rerun-focused.raw.log"
env -i PATH="$nodebin:/usr/bin:/bin" HOME="$evidence" CI=1 "$nodebin/node" ../../node_modules/vitest/vitest.mjs run --config "$evidence/vitest.config.ts" --maxWorkers=2 2>&1 | tee "$evidence/rerun-probes.raw.log"

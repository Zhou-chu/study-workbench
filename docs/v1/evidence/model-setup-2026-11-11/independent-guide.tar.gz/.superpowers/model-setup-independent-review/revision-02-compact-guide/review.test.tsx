import { act, fireEvent, screen, waitFor, within } from '@testing-library/react';
import { expect, it } from 'vitest';
import { readTurnContext, sessionCoordinator } from '@study/web-transport';
import { renderLibrary } from '../../../apps/web/src/test/library-harness';
import { configurationServer, configuredModels } from '../../../apps/web/src/test/configuration-fixtures';
import { json } from '../../../apps/web/src/test/notebook-fixtures';
const overview = () => screen.getByRole('region', { name: 'Model setup' });
const value = (name: string) => within(overview()).getByText(name, { selector: 'dt' }).nextElementSibling!;
const validation = () => value('External validation');
const accept = () => fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', {name:'Confirm action'}));
async function ready() {
 const h=await renderLibrary('/settings/models');
 await waitFor(()=>expect(screen.getByRole('button',{name:'Auto-assign Defaults'})).toBeEnabled());
 return h;
}
async function check(button='Test Model Chat fixture') {
 fireEvent.click(screen.getByRole('button',{name:button})); accept();
 await waitFor(()=>expect(validation()).not.toHaveTextContent(/Checking|No current/));
}
function server(message='Synthetic response', details: string | null = null) {
 return configurationServer(r=> new URL(r.url).pathname.endsWith('/test') ? json({success:true,message,details}):undefined);
}
it('independent: testing another language model preserves the selected default and never writes defaults',async()=>{
 const requests=configurationServer(r=>{
  const path=new URL(r.url).pathname;
  if(path==='/api/models')return json([...configuredModels,{...configuredModels[0],id:'model:other',name:'Different language model'}]);
  if(path.endsWith('/test'))return json({success:true,message:'Synthetic',details:null});
  return undefined;
 });
 await ready();await check('Test Model Different language model');
 expect(validation()).toHaveTextContent('Different language model');
 expect(validation()).not.toHaveTextContent('Chat fixture');
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 expect(requests.filter(r=>r.method!=='GET').map(r=>decodeURIComponent(new URL(r.url).pathname))).toEqual(['/api/models/model:other/test']);
});
it.each(['retired','provider-revision','models-error'] as const)('independent: a successful receipt is not current after %s',async(reason)=>{
 server();const h=await ready();await check();
 fireEvent.click(within(screen.getByRole('dialog')).getByRole('button',{name:'Close'}));
 act(()=>{
  if(reason==='retired')h.workbench.drafts.retireContext(readTurnContext()!.epoch);
  else if(reason==='provider-revision')h.workbench.controller.invalidateProviderAdmission();
  else {
   const s=h.workbench.drafts.configuration,r=s.getSnapshot().find(v=>v.kind==='models')!;
   const rev=s.loading(r.id,'models')!;s.publish(r.id,'models',rev,null);
  }
 });
 expect(validation()).toHaveTextContent('Previous check');
 expect(validation()).not.toHaveTextContent(/Passed|check reported success/i);
 if(reason!=='provider-revision')expect(value('Current global chat default')).toHaveTextContent('Unknown');
 if(reason==='retired')expect(value('Saved configurations')).toHaveTextContent('Unknown');
});
it('independent: session suspension invalidates current metadata and test claims together',async()=>{
 server();await ready();await check();
 fireEvent.click(within(screen.getByRole('dialog')).getByRole('button',{name:'Close'}));
 act(()=>sessionCoordinator.report('reauth-required',sessionCoordinator.current()));
 await screen.findByLabelText('Password');
 fireEvent.click(screen.getByRole('button',{name:'Close reauthentication'}));
 expect(value('Current global chat default')).toHaveTextContent('Unknown');
 expect(value('Saved configurations')).toHaveTextContent('Unknown');
 expect(validation()).toHaveTextContent('Previous check');
});
it.each([null, 'synthetic-private-rate-limit-details'])('independent: a rate-limited success flag is not an invocation pass (%s)',async(details)=>{
 server('Rate limited - but connection works', details);await ready();await check();
 expect(validation()).not.toHaveTextContent(/\bPassed\b/);
 expect(validation()).toHaveTextContent('a model response is not confirmed');
 expect(validation()).toBeVisible();
 const dialog=within(screen.getByRole('dialog'));
 expect(dialog.getByRole('heading')).toHaveTextContent('Check result received');
 expect(dialog.queryByText(/^(Unknown|None)$/)).toBeNull();
 expect(dialog.getByText(/rate limits.*model response is not confirmed/)).toBeVisible();
 expect(document.body.textContent).not.toContain('synthetic-private-rate-limit-details');
 expect(document.body.textContent).not.toContain('Rate limited - but connection works');
});

it('independent: actions precede closed optional guidance without hiding state facts or sending requests',async()=>{
 const requests=server();await ready();
 const region=overview();
 const defaultLink=within(region).getByRole('link',{name:'Choose the chat default'});
 const modelsLink=within(region).getByRole('link',{name:'Review registered models'});
 const summary=within(region).getByText('How to check whether setup took effect');
 const details=summary.closest('details')!;
 const dl=value('External validation').closest('dl')!;
 expect(details).not.toHaveAttribute('open');
 expect(defaultLink).toBeVisible(); expect(modelsLink).toBeVisible();
 expect(defaultLink).toHaveAttribute('href','#model-default-assignments');
 expect(modelsLink).toHaveAttribute('href','#registered-models');
 expect(dl.compareDocumentPosition(defaultLink)&Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
 expect(defaultLink.compareDocumentPosition(details)&Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
 expect(modelsLink.compareDocumentPosition(details)&Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
 expect(value('Current global chat default')).toBeVisible();
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 const taskBoundary=within(region).getByText(/does not prove that a notebook task/);
 expect(taskBoundary).not.toBeVisible();
 fireEvent.click(summary);
 expect(details).toHaveAttribute('open');expect(taskBoundary).toBeVisible();
 fireEvent.click(summary);
 expect(details).not.toHaveAttribute('open');expect(taskBoundary).not.toBeVisible();
 expect(requests.filter(r=>r.method!=='GET')).toHaveLength(0);
});

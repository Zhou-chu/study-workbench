#!/usr/bin/env bash
# Explicit synthetic-only rerun. No install, build, provider call, or deployment.
set -euo pipefail
repo="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
evidence="$repo/.superpowers/model-setup-independent-review"
export PATH="${REVIEW_NODE_BIN:-/home/USER/study-workbench-deploy-20261107/tools/node-v24.19.0-linux-x64/bin}:/usr/bin:/bin"
export CI=1 NPM_CONFIG_OFFLINE=true NPM_CONFIG_UPDATE_NOTIFIER=false NPM_CONFIG_AUDIT=false NPM_CONFIG_FUND=false
cd "$repo"
sha256sum -c "$evidence/reviewed-source.sha256"
cd "$repo/apps/web"
node ../../node_modules/vitest/vitest.mjs run src/features/settings/model-setup-journey.test.tsx src/features/settings/settings-controls.test.tsx src/features/settings/configuration.test.tsx src/features/settings/model-owner.test.ts src/features/settings/configuration-contracts.test.ts --maxWorkers=2 2>&1 | tee "$evidence/rerun-focused.log"
node ../../node_modules/vitest/vitest.mjs run --config "$evidence/vitest.config.ts" --maxWorkers=2 2>&1 | tee "$evidence/rerun-probes.log"

import { defineConfig } from 'vitest/config';
export default defineConfig({
 root: '/home/USER/study-workbench-worktrees-20261108/notebook-model-setup-20261110/apps/web', envDir: false,
 define: { __SPA_ARTIFACT__: 'null' },
 test: { include: ['/tmp/notebook-model-setup-independent-review-20261110/review.test.tsx'], environment: 'jsdom', setupFiles: ['./src/test/setup.ts'], css: true }
});

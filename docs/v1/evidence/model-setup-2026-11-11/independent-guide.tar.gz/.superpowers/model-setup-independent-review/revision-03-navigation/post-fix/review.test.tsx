import { act, fireEvent, screen, waitFor, within } from '@testing-library/react';
import { expect, it } from 'vitest';
import { readTurnContext, sessionCoordinator } from '@study/web-transport';
import { renderLibrary } from '../../../../apps/web/src/test/library-harness';
import { configurationServer, configuredModels, credentialFixture, modelDefaults } from '../../../../apps/web/src/test/configuration-fixtures';
import { json } from '../../../../apps/web/src/test/notebook-fixtures';
const overview = () => screen.getByRole('region', { name: 'Model setup' });
const value = (name: string) => within(overview()).getByText(name, { selector: 'dt' }).nextElementSibling!;
const validation = () => value('External validation');
const accept = () => fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', {name:'Confirm action'}));
async function ready() {
 const h=await renderLibrary('/settings/models');
 await waitFor(()=>expect(screen.getByRole('button',{name:'Auto-assign Defaults'})).toBeEnabled());
 return h;
}
async function check(button='Test Model Chat fixture') {
 fireEvent.click(screen.getByRole('button',{name:button})); accept();
 await waitFor(()=>expect(validation()).not.toHaveTextContent(/Checking|No current/));
}
function server(message='Synthetic response', details: string | null = null) {
 return configurationServer(r=> new URL(r.url).pathname.endsWith('/test') ? json({success:true,message,details}):undefined);
}
it('independent: testing another language model preserves the selected default and never writes defaults',async()=>{
 const requests=configurationServer(r=>{
  const path=new URL(r.url).pathname;
  if(path==='/api/models')return json([...configuredModels,{...configuredModels[0],id:'model:other',name:'Different language model'}]);
  if(path.endsWith('/test'))return json({success:true,message:'Synthetic',details:null});
  return undefined;
 });
 await ready();await check('Test Model Different language model');
 expect(validation()).toHaveTextContent('Different language model');
 expect(validation()).not.toHaveTextContent('Chat fixture');
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 expect(requests.filter(r=>r.method!=='GET').map(r=>decodeURIComponent(new URL(r.url).pathname))).toEqual(['/api/models/model:other/test']);
});
it.each(['retired','provider-revision','models-error'] as const)('independent: a successful receipt is not current after %s',async(reason)=>{
 server();const h=await ready();await check();
 fireEvent.click(within(screen.getByRole('dialog')).getByRole('button',{name:'Close'}));
 act(()=>{
  if(reason==='retired')h.workbench.drafts.retireContext(readTurnContext()!.epoch);
  else if(reason==='provider-revision')h.workbench.controller.invalidateProviderAdmission();
  else {
   const s=h.workbench.drafts.configuration,r=s.getSnapshot().find(v=>v.kind==='models')!;
   const rev=s.loading(r.id,'models')!;s.publish(r.id,'models',rev,null);
  }
 });
 expect(validation()).toHaveTextContent('Previous check');
 expect(validation()).not.toHaveTextContent(/Passed|check reported success/i);
 if(reason!=='provider-revision')expect(value('Current global chat default')).toHaveTextContent('Unknown');
 if(reason==='retired')expect(value('Saved configurations')).toHaveTextContent('Unknown');
});
it('independent: session suspension invalidates current metadata and test claims together',async()=>{
 server();await ready();await check();
 fireEvent.click(within(screen.getByRole('dialog')).getByRole('button',{name:'Close'}));
 act(()=>sessionCoordinator.report('reauth-required',sessionCoordinator.current()));
 await screen.findByLabelText('Password');
 fireEvent.click(screen.getByRole('button',{name:'Close reauthentication'}));
 expect(value('Current global chat default')).toHaveTextContent('Unknown');
 expect(value('Saved configurations')).toHaveTextContent('Unknown');
 expect(validation()).toHaveTextContent('Previous check');
});
it.each([null, 'synthetic-private-rate-limit-details'])('independent: a rate-limited success flag is not an invocation pass (%s)',async(details)=>{
 server('Rate limited - but connection works', details);await ready();await check();
 expect(validation()).not.toHaveTextContent(/\bPassed\b/);
 expect(validation()).toHaveTextContent('a model response is not confirmed');
 expect(validation()).toBeVisible();
 const dialog=within(screen.getByRole('dialog'));
 expect(dialog.getByRole('heading')).toHaveTextContent('Check result received');
 expect(dialog.queryByText(/^(Unknown|None)$/)).toBeNull();
 expect(dialog.getByText(/rate limits.*model response is not confirmed/)).toBeVisible();
 expect(document.body.textContent).not.toContain('synthetic-private-rate-limit-details');
 expect(document.body.textContent).not.toContain('Rate limited - but connection works');
});

it('independent: actions precede closed optional guidance without hiding state facts or sending requests',async()=>{
 const requests=server();await ready();
 const region=overview();
 const defaultLink=within(region).getByRole('link',{name:'Choose the chat default'});
 const modelsLink=within(region).getByRole('link',{name:'Review registered models'});
 const summary=within(region).getByText('How to check whether setup took effect');
 const details=summary.closest('details')!;
 const dl=value('External validation').closest('dl')!;
 expect(details).not.toHaveAttribute('open');
 expect(defaultLink).toBeVisible(); expect(modelsLink).toBeVisible();
 expect(defaultLink).toHaveAttribute('href','#model-default-assignments');
 expect(modelsLink).toHaveAttribute('href','#registered-models');
 expect(dl.compareDocumentPosition(defaultLink)&Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
 expect(defaultLink.compareDocumentPosition(details)&Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
 expect(modelsLink.compareDocumentPosition(details)&Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
 expect(value('Current global chat default')).toBeVisible();
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 const taskBoundary=within(region).getByText(/does not prove that a notebook task/);
 expect(taskBoundary).not.toBeVisible();
 fireEvent.click(summary);
 expect(details).toHaveAttribute('open');expect(taskBoundary).toBeVisible();
 fireEvent.click(summary);
 expect(details).not.toHaveAttribute('open');expect(taskBoundary).not.toBeVisible();
 expect(requests.filter(r=>r.method!=='GET')).toHaveLength(0);
});

const pendingDeepseek={...credentialFixture,id:'credential:deepseek-pending',provider:'deepseek',name:'New DeepSeek candidate',modalities:['language'],model_count:0};
const navProviders=[
 {name:'openai',display_name:'OpenAI',modalities:['language','embedding'],docs_url:null,env_configured:true},
 {name:'deepseek',display_name:'DeepSeek',modalities:['language'],docs_url:null,env_configured:false}
];
const navPrimary=()=>within(overview()).getAllByRole('link')[0]!;
function navServer(opts: {credentials: object[]; models?: object[]; encryption?: boolean; defaults?: object}) {
 return configurationServer(r=>{
  const path=new URL(r.url).pathname;
  if(path==='/api/providers')return json(navProviders);
  if(path==='/api/credentials')return json(opts.credentials);
  if(path==='/api/models'&&opts.models)return json(opts.models);
  if(path==='/api/models/defaults'&&opts.defaults)return json(opts.defaults);
  if(path==='/api/credentials/status'&&opts.encryption!==undefined)return json({configured:{openai:true},source:{openai:'environment'},encryption_configured:opts.encryption});
  return undefined;
 });
}
it('independent nav: new single DeepSeek credential precedes old default with exact named safe target and no mutation',async()=>{
 const requests=navServer({credentials:[credentialFixture,{...credentialFixture,id:'credential:two',name:'Second configuration',model_count:1},pendingDeepseek]});
 await ready();const primary=navPrimary();
 expect(primary).toHaveTextContent('Register models: DeepSeek');
 expect(primary).toHaveTextContent(pendingDeepseek.name);
 expect(primary.getAttribute('href')).toMatch(/^#model-setup-credential-[a-f0-9]+$/);
 expect(primary.getAttribute('href')).not.toContain(pendingDeepseek.id);
 const target=document.getElementById(primary.getAttribute('href')!.slice(1))!;
 expect(target).toHaveAttribute('tabindex','-1');
 expect(within(target).getByRole('button',{name:'Discover Models '+pendingDeepseek.name})).toBeEnabled();
 fireEvent.click(primary);
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 expect(requests.filter(r=>r.method!=='GET')).toHaveLength(0);
});
it('independent nav: multiple pending configs expose distinct explicit choices without selecting either',async()=>{
 const other={...pendingDeepseek,id:'credential:other-pending',provider:'openai',name:'Other pending'};
 const requests=navServer({credentials:[credentialFixture,{...credentialFixture,id:'credential:two',name:'Second configuration',model_count:1},pendingDeepseek,other]});
 await ready();expect(navPrimary()).toHaveAttribute('href','#model-setup-pending');
 const candidates=within(document.getElementById('model-setup-pending')!).getAllByRole('link');
 expect(candidates).toHaveLength(2);
 expect(new Set(candidates.map(a=>a.getAttribute('href'))).size).toBe(2);
 for(const a of candidates){expect(document.getElementById(a.getAttribute('href')!.slice(1))).not.toBeNull();fireEvent.click(a);}
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 expect(requests.filter(r=>r.method!=='GET')).toHaveLength(0);
});
it('independent nav: null-bound environment model is not confused with a missing saved credential',async()=>{
 navServer({credentials:[],models:[{...configuredModels[0],credential:null}]});
 await ready();expect(navPrimary()).toHaveAttribute('href','#model-default-assignments');
});
it('independent nav: dangling saved-credential reference must not be presented as an environment model ready for default choice',async()=>{
 navServer({credentials:[],models:[{...configuredModels[0],credential:'credential:missing'}]});
 await ready();expect(navPrimary()).toHaveAttribute('href','#model-setup-status');
});
it('independent nav: empty setup without encryption points to its blocker rather than disabled add controls',async()=>{
 navServer({credentials:[],models:[],encryption:false,defaults:{...modelDefaults,default_chat_model:null,default_embedding_model:null}});
 await ready();
 expect(screen.getByRole('button',{name:'Add Configuration: OpenAI'})).toBeDisabled();
 expect(navPrimary()).toHaveAttribute('href','#model-setup-status');
});
it('independent nav: encryption missing does not hide a valid environment-backed language-model choice',async()=>{
 navServer({credentials:[],models:[{...configuredModels[0],credential:null}],encryption:false});
 await ready();expect(navPrimary()).toHaveAttribute('href','#model-default-assignments');
});
it('independent nav: when no language model exists, an already-saved language-capable embedding credential has a registration next step',async()=>{
 navServer({credentials:[{...credentialFixture,model_count:1}],models:[configuredModels[1]],defaults:{...modelDefaults,default_chat_model:null}});
 await ready();expect(navPrimary()).toHaveTextContent('Register models: OpenAI');
 expect(navPrimary()).toHaveTextContent(credentialFixture.name);
 const target=document.getElementById(navPrimary().getAttribute('href')!.slice(1))!;
 expect(within(target).getByRole('button',{name:'Discover Models '+credentialFixture.name})).toBeEnabled();
});

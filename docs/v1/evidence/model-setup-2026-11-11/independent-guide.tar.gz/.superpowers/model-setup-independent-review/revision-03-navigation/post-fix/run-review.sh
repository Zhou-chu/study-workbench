#!/usr/bin/env bash
set -euo pipefail
evidence="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$evidence/../../../.." && pwd)"
node=/home/USER/study-workbench-deploy-20261107/tools/node-v24.19.0-linux-x64/bin/node
cd "$repo/apps/web"
env -i PATH="$(dirname "$node"):/usr/bin:/bin" HOME="$evidence" CI=1 "$node" "$repo/node_modules/vitest/vitest.mjs" run src/features/settings/model-setup-journey.test.tsx src/features/settings/settings-controls.test.tsx src/features/settings/configuration.test.tsx src/features/settings/model-owner.test.ts src/features/settings/configuration-contracts.test.ts --maxWorkers=2
env -i PATH="$(dirname "$node"):/usr/bin:/bin" HOME="$evidence" CI=1 "$node" "$repo/node_modules/vitest/vitest.mjs" run --config "$evidence/vitest.config.ts" --maxWorkers=2
git diff --check

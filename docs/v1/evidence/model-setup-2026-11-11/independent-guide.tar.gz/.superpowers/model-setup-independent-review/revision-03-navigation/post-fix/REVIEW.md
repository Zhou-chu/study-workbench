# Revision 03 post-fix independent review

## Decision

The three independently reproduced navigation defects R4-R6 are resolved in the exact source snapshot identified by reviewed-source.sha256. No remaining blocking finding was identified in this scoped read-only configuration-navigation and state/receipt review.

This is a code and synthetic regression decision, not real-user acceptance, provider verification, task-use verification, or overall J12 approval. The existing separately assigned shared-header 200% zoom and dialog Escape/focus issues remain outside this change; the parent owns their status and affected browser verification.

## Independent execution

Executed serially in the exclusive review window on 2026-11-10, 19:34:34-19:34:57 UTC:

- Five focused suites: 171/171 passed, exit 0. Breakdown: settings-controls 60, configuration 50, configuration-contracts 8, model-owner 4, model-setup-journey 49.
- Independent reviewer harness: 15/15 passed, exit 0.
- git diff --check: exit 0.
- Before/after SHA-256 hashes for all five scoped implementation/test files match.
- The reviewer test source is byte-identical to the preserved pre-fix 15-test harness. No expectation was weakened or excluded to obtain green.
- Logs are raw captured subprocess stdout/stderr bytes, not reconstructed transcripts. Exact commands, environment, UTC timestamps, exit statuses and hashes are in run-record.json.
- This review did not independently rerun types/lint. The implementer's separate passing report is not counted as independent execution here.
- The completed command session was 74607, final exit 0. The testing window was explicitly released to the implementer for affected synthetic browser QA.

## Resolved findings, severity distinct from priority

All three pre-fix findings were S2 severity, with suggested P1 delivery priority. S and P are separate classifications from the authoritative specification.

### R4: Non-null dangling credential reference

Resolved at apps/web/src/features/settings/ModelSetupGuide.tsx:55-60. A language model with a non-null credential reference must match a present, same-provider, non-decryption-error credential; otherwise the primary navigation falls back to configuration status.

- Independent probe review.test.tsx:147-150 now passes.
- A genuine credential:null model retains the default-selection path, including when encryption is not configured.
- This adds a read-only consistency check and does not mutate, relink, test or change the global default.

### R5: Missing encryption prerequisite for adding configuration

Resolved at ModelSetupGuide.tsx:71-73 with the action-specific canAddConfiguration input from ModelsPage.tsx:187.

- The empty setup + encryption_configured=false probe now points to #model-setup-status while the existing Add control remains disabled.
- The matched counterexample, an existing null-bound environment language model with encryption_configured=false, still points to #model-default-assignments.
- Independent probes review.test.tsx:151-160 pass.
- Encryption is not used as an indiscriminate gate on all configuration navigation.

### R6: Multi-purpose credential with only embedding registration

Resolved at ModelSetupGuide.tsx:55,61. model_count remains a total-model count; when there are no registered language models globally and the metadata/relations pass the existing consistency checks, a language-capable saved credential can be a registration candidate despite already having a linked embedding model.

- Independent probe review.test.tsx:161-167 passes without modification.
- A valid existing language-model path does not require every multi-purpose embedding credential to register another language model. The original default-choice probe and the new focused regression both pass.
- Only the named read-only registration destination changes; discovery/registration and defaults still require their existing explicit controls.

## Other reviewed boundaries retained

- Source availability, current owner and retirement gate navigation: ModelSetupGuide.tsx:9-10,26-29,51-60. Unknown/error/stale metadata does not become zero or ready.
- One pending language credential gets an explicit provider/configuration destination; multiple candidates remain separate choices. No automatic default, registration, test or relink.
- Encoded focusable anchors remain safe and unique for credential identifiers: ModelSetupGuide.tsx:13-14 and ModelsPage.tsx:209.
- The current global default and latest test target remain distinct facts.
- success:true remains a neutral receipt with the same-field visible model-response-not-confirmed boundary. It does not establish actual invocation or task use: ModelSetupGuide.tsx:38-49,81.
- Non-default target, retired record, provider revision, models read error, session suspension, and rate-limited positive receipt probes pass.
- Actions still precede the collapsed native disclosure; optional guidance does not hide the current receipt boundary.
- ModelsPage action guards remain in place: currentComplete/queue/editor at lines 35-64, plus the existing explicit action controls. This reviewer did not change source, transport, stores, credential editor, backend or shared components.

## Evidence and reproducibility

- REVIEW.md: this decision and scope.
- focused.raw.log, probes.raw.log, diff-check.raw.log: raw independent executions.
- review.test.tsx and vitest.config.ts: reproducible reviewer harness.
- run-review.sh: repeats the same commands without overwriting stored evidence. Run only in a coordinated testing window with the stated existing dependency installation.
- run-record.json: exact commands/environment, timestamps, exits, source fingerprint and equality checks.
- reviewed-source.sha256: exact five-file source fingerprint.
- SHA256SUMS: manifest for evidence files.

Preserved RED evidence remains separately at ../pre-fix/ and was not overwritten. Its SHA256SUMS digest remains 8286a66e49d2c02e60793b488bd280d59f48c79ad591d2e239f66445c9f3a171. The original and revision-02 reports retain their historical snapshot scope and are not claims about later integrated code.

The repository ignores .superpowers/. If this evidence must be included in a final change, the parent must explicitly include the intended files. The reviewer did not stage, commit, push, merge, build or deploy.

## NOT_RUN and remaining acceptance boundaries

Real provider/API calls, credential use, notebook task use, live persistence and deployment remain NOT_RUN. User browser profiles and CUA were not accessed. Actual rendering, geometry, keyboard focus and screenshot acceptance were not established by jsdom; the implementer has the released window for the affected browser checks. No blanket J12 pass is claimed.

Authoritative specification: https://chatgpt.com/space/page_48a624e1d6908191887f55de4294d2d7 (CFG01-08, J02-04, J12), read in full for this review series. Scoped design and plan remain docs/superpowers/specs/2026-11-10-model-setup-journey-design.md and docs/superpowers/plans/2026-11-10-model-setup-journey.md.

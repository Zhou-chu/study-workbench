import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';
export default defineConfig({
 root: fileURLToPath(new URL('../../../../apps/web/', import.meta.url)),
 envDir: false,
 define: { __SPA_ARTIFACT__: 'null' },
 test: {
  include: [fileURLToPath(new URL('./review.test.tsx', import.meta.url))],
  environment: 'jsdom',
  setupFiles: [fileURLToPath(new URL('../../../../apps/web/src/test/setup.ts', import.meta.url))],
  css: true
 }
});

# Revision 03 pre-fix independent review: navigation boundary failures

## Decision

DO NOT ACCEPT this frozen navigation snapshot yet. Existing focused suites passed 166/166, but independent probes failed 3/15 (12 passed). Three S2 findings remain in the scoped next-step navigation; suggested delivery priority is P1 for each. No implementation file was changed by the reviewer.

The complete raw process outputs, probe source, exact commands, UTC timestamps, exit statuses and before/after source hashes are preserved here. source_unchanged is true in run-record.json. The authoritative specification and prior review boundaries remain those recorded in the parent review directories.

## R4: A dangling credential reference is treated like an environment-backed model

- Severity S2; delivery priority P1. Requirement mapping: CFG03-CFG05, J04.
- Source: ModelSetupGuide.tsx:54-66 in this snapshot.
- Setup: credentials=[], one registered language model whose credential is credential:missing, normal complete provider/default metadata.
- Expected: safe configuration-status review, because null (explicitly unbound/environment path) and a non-null missing saved-credential reference are different facts.
- Actual: primary href is #model-default-assignments.
- Mechanism: unresolved checks only existing languageCredentials. The missing referenced credential is absent from that loop; the later branch checks only model.type === language.
- Independent probe: review.test.tsx:147-150.
- Control: a genuine credential:null language model passed its default-choice probe.

## R5: The add-configuration next step ignores its existing encryption prerequisite

- Severity S2; delivery priority P1. Requirement mapping: CFG01, CFG05, J02/J04.
- Source: ModelSetupGuide.tsx:67-69 and ModelsPage.tsx navigationReady=complete.
- Setup: credentials=[], models=[], null required defaults, encryption_configured=false.
- Expected: primary goes to existing configuration status/encryption explanation.
- Actual: primary href is #model-setup-providers, while Add Configuration: OpenAI is disabled.
- Mechanism: complete means setup metadata was loaded, not that encryption is configured. The add branch does not carry the action-specific encryption prerequisite.
- Independent probe: review.test.tsx:151-156.
- Required non-regression: absence of encryption must not block default selection for an already registered credential:null environment language model; that control probe passed.

## R6: A valid multi-purpose credential with only embedding models gets no chat-registration step

- Severity S2; delivery priority P1. Requirement mapping: CFG04-CFG05, CFG07, J02.
- Source: ModelSetupGuide.tsx:57,65-69.
- Setup: one credential supports language and embedding, model_count=1, and exactly one registered linked embedding model. default_chat_model=null; there is no registered language model anywhere.
- Expected: a read-only registration link to that existing credential, with the explicit existing discovery/registration controls. No automatic registration/default/relink.
- Actual: primary label is Review configuration status, despite consistent metadata and an available registration path.
- Mechanism: model_count is a count across model types, not proof that a language model is registered.
- Independent probe: review.test.tsx:161-167.
- Important constraint: do not indiscriminately require every multi-purpose credential to register language models when a valid global language-model path already exists. Address the no-language-model case without overriding intentional embedding use.

## Independent execution

- Five focused suites: 166/166 passed; exit 0.
- Reviewer harness: 15 tests; 12 passed and 3 failed; exit 1.
- The three failures correspond exactly to R4-R6. Original eight state/receipt/disclosure probes passed, as did single/multiple pending registration and environment/no-encryption controls.
- Logs: focused.raw.log and probes.raw.log, captured as raw subprocess bytes.
- Metadata: run-record.json records the exact commands/environment and source fingerprint.
- This directory is a preserved RED snapshot; a later successful review must be written separately, not overwrite this evidence.

## Remaining boundaries

Real provider calls, task use, live persistence, user browser/CUA and deployment were not performed. J12 overall remains unaccepted; separately assigned shared-header/zoom and dialog-focus issues were not mixed into this repair. These synthetic failures and passes do not determine actual browser geometry or visual acceptance.

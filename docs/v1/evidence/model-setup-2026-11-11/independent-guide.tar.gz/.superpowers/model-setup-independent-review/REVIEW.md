# Independent review: Notebook model setup journey

## Conclusion and scope

The frozen scoped diff has no unresolved code-level S0/S1 finding and no unresolved new S2 finding identified by this review. The corrected display behavior passed independent synthetic checks. This is not real-user acceptance and does not establish real provider, persistence, task execution, browser, visual, deployment, or CI acceptance.

The review read the complete authoritative specification first, then the scoped design, plan and test materials, before implementation summaries:
- https://chatgpt.com/space/page_48a624e1d6908191887f55de4294d2d7
- docs/superpowers/specs/2026-11-10-model-setup-journey-design.md
- docs/superpowers/plans/2026-11-10-model-setup-journey.md
- Relevant scope: CFG01-CFG08, J02-J04, J12. Requirements outside this scoped change are not implicitly accepted.

Reviewed checkout:
- /home/USER/study-workbench-worktrees-20261108/notebook-model-setup-20261110
- Base HEAD: 9ee810fe30fc3723ff18068d2514abf1212a3130
- The reviewed implementation was uncommitted. Exact relevant file hashes are in reviewed-source.sha256.
- Evidence was preserved on 2026-11-10 UTC. The test runner printed host-local starts 03:56:48 and 03:57:14; no timezone inference is made from those host strings.
- The four recorded source hashes were rechecked before persistence and still matched.

## Findings and disposition

Severity S and delivery priority P are separate classifications.

### R1: Non-language configurations were directed to an impossible chat default
- Severity: S2. Suggested delivery priority: P1. Mapping: CFG07, J03.
- Earlier code used the same zero-linked-model hint for every credential, telling the user to choose a chat default. Existing provider metadata supports embedding-only and speech-only credentials, whereas the chat selector accepts language models.
- Corrected behavior: non-language configurations are directed to their matching task, explicitly naming document search, audio generation, or speech transcription.
- Final location: apps/web/src/features/settings/ModelSetupGuide.tsx:62-72 and apps/web/src/i18n/model-setup-messages.ts.
- Evidence: independent focused run includes the three non-language guidance cases.
- Disposition: repaired and independently verified at the synthetic UI level; real browser acceptance NOT_RUN.

### R2: Retained metadata could be displayed as current after a session fence
- Severity: S2. Suggested delivery priority: P1. Mapping: CFG02-CFG05, J04.
- Initial review identified that ready source phases plus non-retired alone did not cover session suspension; the owner can retain readable metadata when dispatch readiness is suspended.
- Corrected behavior: guideCurrent requires config.ready and !config.locked; unavailable, retired, loading, read-error and unknown-write states cannot project old metadata as current. Test evidence also uses metadata revision, session generation and provider-evidence revision.
- Final locations: apps/web/src/features/settings/ModelsPage.tsx:184-191; ModelSetupGuide.tsx:20-43.
- Evidence: independent probes cover session suspension; retired, provider-revision and models-error invalidation after a successful receipt. Focused tests also cover uncertain defaults writes and metadata loading/error.
- Disposition: repaired and independently verified on synthetic state transitions. The reviewer did not independently rerun the pre-fix RED version; implementation-worker RED results are not counted as independent evidence.

### R3: A successful test boolean was overstated as target-model invocation success
- Severity: S2. Suggested delivery priority: P1. Mapping: CFG03, J04.
- Confirmed backend contract: open_notebook/ai/connection_tester.py:457-458 maps rate-limit/quota errors to success=True and a connection-only message; :605-615 propagates that boolean through an individual-model test. The frontend safe projection intentionally does not expose the raw message.
- Earlier guide behavior therefore labeled a 429/quota response as a model check Passed despite no completed model response.
- Corrected behavior: every success:true receipt has the neutral Check result received label plus a model response is not confirmed in the same field. The result dialog is neutral and has the fixed rate-limit limitation. false, unknown, not-sent and stale evidence remain distinct. details_present does not grant invocation evidence. Raw provider messages/details are not rendered.
- Final locations: ModelSetupGuide.tsx:39-54; model-setup-messages.ts:10-12,33-35; ModelsPage.tsx:273.
- Evidence: four focused cases cover connection/model tests with and without private details; an additional independent probe uses the exact connection-only rate-limit message.
- Disposition: repaired and independently verified at the safe UI projection level. The backend boolean is still insufficient to prove invocation or task use, which the UI now discloses.

## Preserved safeguards

Read-only diff review found no changes to the configuration store, transport, backend, CredentialEditor, NotebookShell, captured confirmations, encryption gates, private-input custody, unknown-write fence, or default/relink mutation logic. The guide does not automatically test, discover, register, select a default or rebind credentials. Default selection and the tested target are shown separately.

The independent non-default-language probe observed exactly one model-test request and no defaults write. Focused tests cover the existing confirmation, ownership, stale metadata, credential input and provider-control paths. These findings are scoped and do not mean every historical capability was independently accepted.

## Independent execution

1. Five focused suites, maxWorkers=2: 150/150 passed, 5 files passed, exit 0.
   - settings-controls: 60
   - configuration: 50
   - configuration-contracts: 8
   - model-owner: 4
   - model-setup-journey: 28
2. Separate reviewer-written harness: 6/6 passed, 1 file passed, exit 0.
   - Testing another language model preserves the default and sends only that test.
   - A successful receipt is not current after retirement.
   - A successful receipt is not current after provider-evidence revision change.
   - A successful receipt is not current after model-metadata read error.
   - Session suspension invalidates current metadata and test claims.
   - A rate-limited success flag is not an invocation pass and its raw message is hidden.
3. git diff --check: exit 0.

Logs:
- focused-150.tool-transcript.log
- probes-6.tool-transcript.log

These log files are transparent normalized transcriptions of the original captured tool output, not invented reruns or unmodified raw process-log files. They identify the exec sessions/chunks. ANSI color escapes and unrelated WSL startup encoding noise were removed; check marks are represented by PASS. Counts, durations, test names and exit status come from the original tool results.

## Reproduction and evidence files

- original-review.test.tsx and original-vitest.config.ts preserve the exact harness source/config executed from /tmp.
- review.test.tsx contains the identical assertions with only checkout-absolute imports made relative for this durable directory.
- vitest.config.ts contains equivalent root/include/setup paths derived from its location, avoiding the original temporary directory.
- run-review.sh verifies the source snapshot then reruns both suites sequentially using existing prepared dependencies. Invoke with bash; do not install anything.
- From the checkout: bash .superpowers/model-setup-independent-review/run-review.sh
- Optional REVIEW_NODE_BIN may point to an already prepared compatible Node bin directory.
- This persistence step did not rerun tests because visual QA was being coordinated separately. The portable path adaptation has been content-compared to the executed original; only the original harness has execution evidence so far.
- No production or test source file was modified by the reviewer. Only this evidence directory was added at the parent's request.
- SHA256SUMS hashes the evidence files, excluding itself. Future rerun logs are separate from the preserved original evidence.

## Remaining gates: NOT_RUN in this independent review

- Real provider connection/authentication and target-model invocation.
- Actual notebook task use of the selected configuration; a real J02 complete task.
- Real backend persistence, live credentials and user notebooks.
- Actual browser interaction, required viewports/themes/zoom, soft keyboard and visual acceptance (J12).
- Full repository aggregate checks, production build, CI, merge, deployment or publication.

Independent reviewer agreement and synthetic UI results cannot substitute for these gates or user visual approval.

import { act, fireEvent, screen, waitFor, within } from '@testing-library/react';
import { expect, it } from 'vitest';
import { readTurnContext, sessionCoordinator } from '@study/web-transport';
import { renderLibrary } from '/home/USER/study-workbench-worktrees-20261108/notebook-model-setup-20261110/apps/web/src/test/library-harness';
import { configurationServer, configuredModels } from '/home/USER/study-workbench-worktrees-20261108/notebook-model-setup-20261110/apps/web/src/test/configuration-fixtures';
import { json } from '/home/USER/study-workbench-worktrees-20261108/notebook-model-setup-20261110/apps/web/src/test/notebook-fixtures';
const overview = () => screen.getByRole('region', { name: 'Model setup' });
const value = (name: string) => within(overview()).getByText(name, { selector: 'dt' }).nextElementSibling!;
const validation = () => value('External validation');
const accept = () => fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', {name:'Confirm action'}));
async function ready() {
 const h=await renderLibrary('/settings/models');
 await waitFor(()=>expect(screen.getByRole('button',{name:'Auto-assign Defaults'})).toBeEnabled());
 return h;
}
async function check(button='Test Model Chat fixture') {
 fireEvent.click(screen.getByRole('button',{name:button})); accept();
 await waitFor(()=>expect(validation()).not.toHaveTextContent(/Checking|No current/));
}
function server(message='Synthetic response') {
 return configurationServer(r=> new URL(r.url).pathname.endsWith('/test') ? json({success:true,message,details:null}):undefined);
}
it('independent: testing another language model preserves the selected default and never writes defaults',async()=>{
 const requests=configurationServer(r=>{
  const path=new URL(r.url).pathname;
  if(path==='/api/models')return json([...configuredModels,{...configuredModels[0],id:'model:other',name:'Different language model'}]);
  if(path.endsWith('/test'))return json({success:true,message:'Synthetic',details:null});
  return undefined;
 });
 await ready();await check('Test Model Different language model');
 expect(validation()).toHaveTextContent('Different language model');
 expect(validation()).not.toHaveTextContent('Chat fixture');
 expect(value('Current global chat default')).toHaveTextContent(/OpenAI.*Chat fixture/);
 expect(requests.filter(r=>r.method!=='GET').map(r=>decodeURIComponent(new URL(r.url).pathname))).toEqual(['/api/models/model:other/test']);
});
it.each(['retired','provider-revision','models-error'] as const)('independent: a successful receipt is not current after %s',async(reason)=>{
 server();const h=await ready();await check();
 fireEvent.click(within(screen.getByRole('dialog')).getByRole('button',{name:'Close'}));
 act(()=>{
  if(reason==='retired')h.workbench.drafts.retireContext(readTurnContext()!.epoch);
  else if(reason==='provider-revision')h.workbench.controller.invalidateProviderAdmission();
  else {
   const s=h.workbench.drafts.configuration,r=s.getSnapshot().find(v=>v.kind==='models')!;
   const rev=s.loading(r.id,'models')!;s.publish(r.id,'models',rev,null);
  }
 });
 expect(validation()).toHaveTextContent('Previous check');
 expect(validation()).not.toHaveTextContent(/Passed|check reported success/i);
 if(reason!=='provider-revision')expect(value('Current global chat default')).toHaveTextContent('Unknown');
 if(reason==='retired')expect(value('Saved configurations')).toHaveTextContent('Unknown');
});
it('independent: session suspension invalidates current metadata and test claims together',async()=>{
 server();await ready();await check();
 fireEvent.click(within(screen.getByRole('dialog')).getByRole('button',{name:'Close'}));
 act(()=>sessionCoordinator.report('reauth-required',sessionCoordinator.current()));
 await screen.findByLabelText('Password');
 fireEvent.click(screen.getByRole('button',{name:'Close reauthentication'}));
 expect(value('Current global chat default')).toHaveTextContent('Unknown');
 expect(value('Saved configurations')).toHaveTextContent('Unknown');
 expect(validation()).toHaveTextContent('Previous check');
});
it('independent: a rate-limited success flag is not presented as a model invocation pass',async()=>{
 server('Rate limited - but connection works');await ready();await check();
 expect(validation()).not.toHaveTextContent(/\bPassed\b/);
 expect(overview().textContent).toMatch(/model response is not confirmed|invocation/);
 expect(document.body.textContent).not.toContain('Rate limited - but connection works');
});

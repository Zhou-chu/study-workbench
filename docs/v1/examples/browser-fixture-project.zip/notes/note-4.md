# Known locations: fixture_a.pdf

Five public known-reference fixtures, authored without a model.

- [fixture_a.pdf](../originals/9d0cd69bbcc02c806f065d2e456b5a08f38c5822c342226d964125077b982032.pdf), PDF page 1
  课程 A：太阳能
光伏效应是半导体吸收光子后产生电势差的现象。
实验 A 的转换效率为百分之二十。

- [fixture_a.pdf](../originals/9d0cd69bbcc02c806f065d2e456b5a08f38c5822c342226d964125077b982032.pdf), PDF page 2
  课程 A：储能
共同短语：可靠证据来自原件。
电池储存的是化学能。

- [fixture_a.pdf](../originals/9d0cd69bbcc02c806f065d2e456b5a08f38c5822c342226d964125077b982032.pdf), PDF page 3
  课程 A：参数
实验 A 的标准温度为二十五摄氏度。
不要将物理页码与印刷页码混淆。

- [fixture_a.pdf](../originals/9d0cd69bbcc02c806f065d2e456b5a08f38c5822c342226d964125077b982032.pdf), PDF page 1
  课程 A：太阳能
光伏效应是半导体吸收光子后产生电势差的现象。
实验 A 的转换效率为百分之二十。

- [fixture_a.pdf](../originals/9d0cd69bbcc02c806f065d2e456b5a08f38c5822c342226d964125077b982032.pdf), PDF page 2
  课程 A：储能
共同短语：可靠证据来自原件。
电池储存的是化学能。
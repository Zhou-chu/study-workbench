# PDF navigation fixture

Public authored note for physical-page navigation; no model answer.

- [fixture_a.pdf](../originals/9d0cd69bbcc02c806f065d2e456b5a08f38c5822c342226d964125077b982032.pdf), PDF page 3
  课程 A：参数
实验 A 的标准温度为二十五摄氏度。
不要将物理页码与印刷页码混淆。
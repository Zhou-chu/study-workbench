# Browser note

Created through Playwright against the real API.
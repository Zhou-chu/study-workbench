# Known locations: fixture_b.pdf

Five public known-reference fixtures, authored without a model.

- [fixture_b.pdf](../originals/d94cea49810b0e3c132428b612ca886001fb5337cb13664e5f61323c10bc258c.pdf), PDF page 1
  课程 B：风能
风力发电机将风的动能转化为电能。

- [fixture_b.pdf](../originals/d94cea49810b0e3c132428b612ca886001fb5337cb13664e5f61323c10bc258c.pdf), PDF page 2
  课程 B：参数
共同短语：可靠证据来自原件。
实验 B 的转换效率为百分之三十五。

- [fixture_b.pdf](../originals/d94cea49810b0e3c132428b612ca886001fb5337cb13664e5f61323c10bc258c.pdf), PDF page 3
  课程 B：限制
共同短语：可靠证据来自原件。
此材料没有描述光伏效应。

- [fixture_b.pdf](../originals/d94cea49810b0e3c132428b612ca886001fb5337cb13664e5f61323c10bc258c.pdf), PDF page 4
  课程 B：结论
实验 B 的标准温度为十五摄氏度。

- [fixture_b.pdf](../originals/d94cea49810b0e3c132428b612ca886001fb5337cb13664e5f61323c10bc258c.pdf), PDF page 1
  课程 B：风能
风力发电机将风的动能转化为电能。
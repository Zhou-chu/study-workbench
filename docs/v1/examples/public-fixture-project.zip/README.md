StudyWorkbench portable project, format 1.

Includes immutable originals, extraction text, evidence, notes, normalized visible chat and saved assets.
Missing originals and unfinished jobs are listed in manifest.json.
Credentials, Google sessions, model keys, embeddings and raw LangGraph checkpoints are excluded.
Restore creates new identities; remote links require re-verification and historical jobs never replay.
